package Practice.SocketBasic;

import RifatSirCodes.util.NetworkUtil;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Objects;

public class Server {
    private NetworkUtil nc;

    Server() {
        try {
            ServerSocket welcomeSocket = new ServerSocket(6666);
            System.out.println("Server started at port: " + 6666);
            System.out.println("Waiting for a client...");

            Socket clientSocket = welcomeSocket.accept();
            System.out.println("Client accepted");
            nc = new NetworkUtil(clientSocket);

            while(true) {
                String str = (String) nc.read();
                System.out.println(str);
                if(str.equalsIgnoreCase("over")) {
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            Objects.requireNonNull(nc).closeConnection();
        }
    }

    public static void main(String[] args) {
        Server server = new Server();
    }
}
