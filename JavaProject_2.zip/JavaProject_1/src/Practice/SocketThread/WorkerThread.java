package Practice.SocketThread;

import RifatSirCodes.util.NetworkUtil;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

class WorkerThread implements Runnable {
    private NetworkUtil nc;
    private Thread th;

    WorkerThread(NetworkUtil nc) {
        this.nc = nc;
        th = new Thread(this);
        th.start();
    }

    @Override
    public void run() {
        try {
            Date date = new Date();
            DateFormat fordate = new SimpleDateFormat("yyyy/MM/dd");
            DateFormat fortime = new SimpleDateFormat("hh:mm:ss");

            while(true) {
                nc.write("Enter your choice: 1. Date 2. Time ");
                int ch = (int) nc.read();
                switch (ch) {
                    case 1 : {
                        nc.write(fordate.format(date));
                        break;
                    }
                    case 2 : {
                        nc.write(fortime.format(date));
                        break;
                    }
                    default : {
                        nc.write("Wrong choice");
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            nc.closeConnection();
        }
    }
}
