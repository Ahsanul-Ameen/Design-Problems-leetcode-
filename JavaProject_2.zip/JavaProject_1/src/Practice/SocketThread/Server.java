package Practice.SocketThread;

import RifatSirCodes.util.NetworkUtil;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

class Server {
    public int clientCount;

    Server() {
        try {
            ServerSocket serverSocket = new ServerSocket(6666);
            while(true) {
                Socket clientSocket = serverSocket.accept();
                serve(clientSocket);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void serve(Socket socket) {
        ++clientCount;
        NetworkUtil nc = new NetworkUtil(socket);
        new WorkerThread(nc);
    }

    public static void main(String[] args) {
        Server server = new Server();
    }
}
