package Practice.Online_108.tcpdiff;

import Practice.Online_108.Message.BMessage;
import Practice.Online_108.Message.SMessage;
import Practice.Online_108.util.NetworkUtil;

import java.util.Scanner;



public class WriteThreadClient implements Runnable {

    private Thread thr;
    private NetworkUtil nc;
    String name;

    public WriteThreadClient(NetworkUtil nc, String name) {
        this.nc = nc;
        this.name = name;
        this.thr = new Thread(this);
        thr.start();
    }

    public void run() {
        try {
            Scanner input = new Scanner(System.in);
            while (true) {

                System.out.println("Choose 1. SMessage 2. BMessage ....");
                int choice = input.nextInt();
                if(choice == 1) {
                    System.out.print("from: ");
                    String clientName = input.next();
                    System.out.print("password: ");
                    String password = input.next();
                    System.out.print("text: ");
                    String text = input.next();

                    SMessage sMessage = new SMessage(clientName, password, text);
                    nc.write(sMessage);
                } else if(choice == 2) {
                    System.out.print("from: ");
                    String clientName = input.next();
                    System.out.print("password: ");
                    String password = input.next();
                    System.out.print("text: ");
                    String text = input.next();
                    System.out.println("forServer: ");
                    boolean forServer = input.nextBoolean();

                    BMessage bMessage = new BMessage(clientName, password, text, forServer);
                    nc.write(bMessage);
                } else {
                    continue;
                }


                String s = input.nextLine();
                nc.write(name + ":" + s);



            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            nc.closeConnection();
        }
    }
}



