package Practice.Online_108.tcpdiff;

import Practice.Online_108.Message.LMessage;
import Practice.Online_108.util.NetworkUtil;

import java.util.HashMap;
import java.util.Scanner;
import java.util.StringTokenizer;



public class WriteThreadServer implements Runnable {

    private Thread thr;
    String name;
    public  HashMap<LMessage, NetworkUtil> clientMap;



    public WriteThreadServer(HashMap<LMessage, NetworkUtil> clientMap, String name) {
        this.clientMap = clientMap;
        this.name = name;
        this.thr = new Thread(this);
        thr.start();
    }

    public void run() {
        try {
            Scanner input = new Scanner(System.in);
            while (true) {
                String s = input.nextLine();
                StringTokenizer st = new StringTokenizer(s);
                String cName = st.nextToken();
                NetworkUtil nc = clientMap.get(cName);
                if (nc != null) {
                    nc.write(name + ":" + s);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}



