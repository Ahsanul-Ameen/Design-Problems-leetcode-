package Practice.Online_108.Message;

import java.io.Serializable;

public class BMessage implements Serializable {
    private String from, password, text;
    private boolean forserver;

    public BMessage(String from, String password, String text, boolean forserver) {
        this.from = from;
        this.password = password;
        this.text = text;
        this.forserver = forserver;
    }


    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public boolean isForserver() {
        return forserver;
    }

    public void setForserver(boolean forserver) {
        this.forserver = forserver;
    }
}
