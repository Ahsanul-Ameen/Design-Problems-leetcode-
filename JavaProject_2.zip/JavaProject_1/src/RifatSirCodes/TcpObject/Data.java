package RifatSirCodes.TcpObject;

import java.io.Serializable;

public class Data implements Serializable {
    private String string;
    Data(String string) {
        this.string = string;
    }
    String getElement() {
        return this.string;
    }
}
