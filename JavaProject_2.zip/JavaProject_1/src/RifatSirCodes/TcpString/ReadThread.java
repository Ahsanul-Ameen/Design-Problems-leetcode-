package RifatSirCodes.TcpString;

import RifatSirCodes.util.NetworkUtil;

public class ReadThread implements Runnable {
    private Thread myThread;
    private NetworkUtil networkUtil;

    ReadThread(NetworkUtil networkUtil) {
        this.networkUtil = networkUtil;
        myThread = new Thread(this, "read thread");
        myThread.start();
    }

    @Override
    public void run() {
        try {
            while(true) {
                String str = (String) networkUtil.read();
                if(str != null) System.out.println(str);
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            networkUtil.closeConnection();
        }
    }
}
