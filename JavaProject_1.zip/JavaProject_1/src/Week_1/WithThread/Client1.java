package Week_1.WithThread;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Client1 {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Socket socket = new Socket("localhost", 6666);

        System.out.println("Connection Established");
        System.out.println("Remote Port: " + socket.getPort());
        System.out.println("Local Port: " + socket.getLocalPort());

        //buffers
        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());

        while(true) {
            System.out.println(ois.readObject());
        }
    }
}
