package Practice.SocketBasic;

import RifatSirCodes.util.NetworkUtil;

import java.util.Scanner;

class Client {
    Client(String serverIP, int serverPort) {
        NetworkUtil nc = new NetworkUtil(serverIP, serverPort);
        System.out.println("Client connected. RemotePort: "
                + nc.remotePort() + ", LocalPort: " + nc.localPort());

        String str = "";
        Scanner scanner = new Scanner(System.in);
        try {   // try writing....
            while(!str.equalsIgnoreCase("over")) {
                str = scanner.nextLine();
                nc.write(str);
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            nc.closeConnection();
        }
    }

    public static void main(String[] args) {
        Client client = new Client("localhost", 6666);
    }
}
