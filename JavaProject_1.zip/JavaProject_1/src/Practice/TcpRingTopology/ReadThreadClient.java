package Practice.TcpRingTopology;

import RifatSirCodes.util.NetworkUtil;

class ReadThreadClient implements Runnable {
    private NetworkUtil nc;
    private Thread th;

    ReadThreadClient(NetworkUtil nc) {
        this.nc = nc;
        th = new Thread(this);
        th.start();
    }

    @Override
    public void run() {
        try {
            while(true) {
                String s = (String) nc.read();
                if(s != null) System.out.println(s);
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            nc.closeConnection();
        }
    }
}