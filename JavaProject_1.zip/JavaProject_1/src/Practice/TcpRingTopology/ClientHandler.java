package Practice.TcpRingTopology;

import RifatSirCodes.util.NetworkUtil;

import java.util.HashMap;
import java.util.Scanner;

class ClientHandler implements Runnable {
    private NetworkUtil nc;
    private HashMap<Integer, NetworkUtil> clientMap;
    private Scanner scanner;
    private Thread th;

    ClientHandler(HashMap<Integer, NetworkUtil> clientMap, NetworkUtil nc) {
        this.nc = nc;
        this.clientMap = clientMap;
        scanner = new Scanner(System.in);
        th = new Thread(this);
        th.start();
    }

    @Override
    public void run() {
        try {
            nc.write("Enter your ID: ");
            Integer id = (Integer) nc.read();
            int next = id+1, prev = id-1;
            if(id == 1) prev = clientMap.size();
            if(clientMap.size() == 1) next = 1;
            System.out.println(id);
           /* while(true) {
                int ch = (int) nc.read();
                if(ch == 1) {
                    nc.write("Enter message: ");
                    String msg = (String) nc.read();
                    clientMap.get(next).write(msg);
                } else if (ch == 2) {
                    nc.write("Enter message: ");
                    String msg = (String) nc.read();
                    clientMap.get(prev).write(msg);
                } else break;
            }*/
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            nc.closeConnection();
        }
    }
}
