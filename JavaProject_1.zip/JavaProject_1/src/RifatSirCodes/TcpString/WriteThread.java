package RifatSirCodes.TcpString;

import RifatSirCodes.util.NetworkUtil;

import java.util.Scanner;

public class WriteThread implements Runnable {
    private NetworkUtil nc;
    private Thread thread;
    private String name;

    WriteThread(NetworkUtil nc, String name) {
        this.nc = nc;
        this.name = name;
        thread = new Thread(this);
        thread.start();
    }

    @Override
    public void run() {
        try {
            Scanner input = new Scanner(System.in);
            while(true) {
                String str = input.nextLine();
                nc.write(name + ": " + str);
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            nc.closeConnection();
        }
    }
}
