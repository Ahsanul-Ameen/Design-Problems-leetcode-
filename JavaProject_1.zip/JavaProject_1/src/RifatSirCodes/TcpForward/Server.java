package RifatSirCodes.TcpForward;

import RifatSirCodes.util.NetworkUtil;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

class Server {
    private ServerSocket serverSocket;
    private int clientCount;
    private HashMap<String, NetworkUtil> clientMap;

    Server() {
        clientMap = new HashMap<>();
        try {
            serverSocket = new ServerSocket(6666);  //create a server socket
            while(true) {
                Socket socket = serverSocket.accept();  // wait and serve
                serve(socket);
            }
        } catch (Exception e) {
            System.out.println("Server starts: " + e);
        }
    }

    private void serve(Socket clientSocket) {
        ++clientCount;
        NetworkUtil nc = new NetworkUtil(clientSocket);
        String clientName = (String) nc.read();  //read client's name;
        System.out.println(clientName + " connected at (server)" +
                " LocalPort: " + nc.localPort() + ", RemotePort: " + nc.remotePort());
        clientMap.put(clientName, nc);
        new ReadThreadServer(clientMap, nc);
    }

    public static void main(String[] args) {
        Server server = new Server();
    }
}
