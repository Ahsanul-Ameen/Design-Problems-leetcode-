package RifatSirCodes.TcpForward;

import RifatSirCodes.util.NetworkUtil;

import java.util.HashMap;

class ReadThreadServer implements Runnable {
    private HashMap<String, NetworkUtil> clientMap; // we need a map!
    private NetworkUtil nc;
    private Thread th;

    public ReadThreadServer(HashMap<String, NetworkUtil> clientMap, NetworkUtil nc) {
        this.clientMap = clientMap;
        this.nc = nc;
        th = new Thread(this);
        th.start();
    }

    @Override
    public void run() { // reads a message from a client and forward it to appropriate Client
        try {
            while(true) {
                Object o = nc.read();
                if(o instanceof Message) {
                    Message msg = (Message) o;
                    NetworkUtil networkUtil = clientMap.get(msg.getTo());
                    if(networkUtil != null) {
                        networkUtil.write(o);
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            nc.closeConnection();
        }
    }

}
