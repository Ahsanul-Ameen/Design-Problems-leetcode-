package RifatSirCodes.TcpObject;

import RifatSirCodes.util.NetworkUtil;

public class Client {
    Client(String serverIP, int serverPort) {
        NetworkUtil nc = new NetworkUtil(serverIP, serverPort);
        new ReadThread(nc);
        new WriteThread(nc, "Client");
    }

    public static void main(String[] args) {
        Client client = new Client("localhost", 6666);
    }
}
