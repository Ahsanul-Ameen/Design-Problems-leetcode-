package RifatSirCodes.TcpDiff;

import RifatSirCodes.util.NetworkUtil;

import java.util.Scanner;

class Client {

    Client(String serverIP, int serverPort) {
        try {
            System.out.println("Enter the name of Client: ");
            Scanner scanner = new Scanner(System.in);
            String clientName = scanner.nextLine();

            NetworkUtil nc = new NetworkUtil(serverIP, serverPort);
            nc.write(clientName); // send your name first
            System.out.println(clientName + " connected, RemotePort: " + nc.remotePort() + ", LocalPort: " + nc.localPort());

            new ReadThread(nc); // for receiving message
            new WriteThreadClient(nc, clientName);  // a write thread with its owner's name
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public static void main(String[] args) {
        Client client = new Client("localhost", 6666);
    }
}
