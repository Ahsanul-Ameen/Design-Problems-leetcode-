package RifatSirCodes.TcpDiff;

import RifatSirCodes.util.NetworkUtil;

import java.util.HashMap;
import java.util.Scanner;
import java.util.StringTokenizer;

public class WriteThreadServer implements Runnable {
    private HashMap<String, NetworkUtil> clientMap;
    private String name;
    private Thread th;

    WriteThreadServer(HashMap<String, NetworkUtil> clientMap, String name) {
        this.clientMap = clientMap;
        this.name = name;
        th = new Thread(this);
        th.start();
    }

    @Override
    public void run() {
        try {
            Scanner scanner = new Scanner(System.in);
            while(true) {

                StringBuilder str = new StringBuilder(scanner.nextLine());
                StringTokenizer st = new StringTokenizer(str.toString());
                String clientName = st.nextToken();
                NetworkUtil nc = clientMap.get(clientName);
                str = new StringBuilder();
                while(st.hasMoreTokens()) {
                    str.append(st.nextToken() + " ");
                }
                if(nc != null) {
                    nc.write(this.name + " : " + str);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
