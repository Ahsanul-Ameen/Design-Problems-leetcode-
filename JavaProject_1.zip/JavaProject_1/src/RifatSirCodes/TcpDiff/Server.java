package RifatSirCodes.TcpDiff;

import RifatSirCodes.util.NetworkUtil;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

class Server {
    private ServerSocket welcomeSocket;
    int clientCount = 0;
    public HashMap<String, NetworkUtil> clientMap;

    Server() {
        clientMap = new HashMap<>();
        try {
            welcomeSocket = new ServerSocket(6666);
            //we're passing the reference of clientMap & a random name of the Server
            new WriteThreadServer(clientMap, "Server"); // needs no NetworkUtil, clientMap is enough

            while(true) {
                Socket socket = welcomeSocket.accept();
                serve(socket);
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }

    }


    private void serve(Socket socket) {
        ++clientCount;
        NetworkUtil nc = new NetworkUtil(socket);
        String clientName = (String) nc.read(); // read ClientName
        System.out.println(clientName + " connected at (server)" +
                " LocalPort: " + nc.localPort() + ", RemotePort: " + nc.remotePort());
        clientMap.put(clientName, nc);  // list this client
        new ReadThread(nc);
    }

    public static void main(String[] args) {
        Server server = new Server();
    }
}
