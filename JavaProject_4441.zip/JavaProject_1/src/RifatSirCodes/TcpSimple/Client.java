package RifatSirCodes.TcpSimple;

import RifatSirCodes.util.NetworkUtil;

public class Client {
    public Client(String serverIP, int serverPort) {
        NetworkUtil networkUtil = new NetworkUtil(serverIP, serverPort);
        String name = "Client C";
        networkUtil.write(name);
        System.out.println(networkUtil.read());
    }

    public static void main(String[] args) {
        Client client = new Client("localhost", 6666);
    }
}
