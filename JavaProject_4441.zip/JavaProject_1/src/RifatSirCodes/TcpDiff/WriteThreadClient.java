package RifatSirCodes.TcpDiff;

import RifatSirCodes.util.NetworkUtil;

import java.util.Scanner;

public class WriteThreadClient implements Runnable {
    private NetworkUtil nc;
    private String name;
    private Thread th;

    WriteThreadClient(NetworkUtil nc, String name) {    // takes an nc, name & writes with name:message
        this.nc = nc;
        this.name = name;
        th = new Thread(this);
        th.start();
    }

    @Override
    public void run() {
        try {
            Scanner input = new Scanner(System.in);
            while(true) {
                String s = input.nextLine();
                nc.write(this.name + ":" + s);
            }
        } catch(Exception e) {
            System.out.println(e);
        }
        finally {
            nc.closeConnection();
        }
    }
}
