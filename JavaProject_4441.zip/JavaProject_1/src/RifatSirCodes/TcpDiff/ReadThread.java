package RifatSirCodes.TcpDiff;

import RifatSirCodes.util.NetworkUtil;

public class ReadThread implements Runnable {       //reads from a particular NetworkUtil/socket
    private NetworkUtil nc;
    private Thread th;

    public ReadThread(NetworkUtil nc) {
        this.nc = nc;
        th = new Thread(this);
        th.start();
    }

    @Override
    public void run() {
        try {
            while (true) {
                String s = (String) nc.read();
                if(s != null) {
                    System.out.println(s);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            nc.closeConnection();
        }
    }
}
