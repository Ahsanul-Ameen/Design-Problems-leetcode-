package RifatSirCodes.TcpForward;

import RifatSirCodes.util.NetworkUtil;

class ReadThreadClient implements Runnable {
    private NetworkUtil nc;
    private Thread th;

    ReadThreadClient(NetworkUtil nc) {
        this.nc = nc;
        th = new Thread(this);
        th.start();
    }

    @Override
    public void run() {
        try {
            while(true) {
                Object o = nc.read();
                if(o instanceof Message) { // check if o is Message type
                    Message message = (Message) o;
                    System.out.println(message.getFrom() + " sends: " + message.getText());
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            nc.closeConnection();
        }
    }
}
