package RifatSirCodes.TcpForward;

import RifatSirCodes.util.NetworkUtil;

import java.util.Scanner;

public class WriteThreadClient implements Runnable {
    private NetworkUtil nc;
    private String name;
    private Thread th;

    WriteThreadClient(NetworkUtil nc, String name) {
        this.nc = nc;
        this.name = name;
        th = new Thread(this);
        th.start();
    }

    @Override
    public void run() {
        try {
            Scanner input = new Scanner(System.in);
            while(true) {
                String from = name;
                System.out.println("Enter name of the client to send: ");
                String to = input.nextLine();
                System.out.println("Enter the message: ");
                String text = input.nextLine();
                Message message = new Message(from, to, text);
                nc.write(message);
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        } finally {
            nc.closeConnection();
        }
    }
}
