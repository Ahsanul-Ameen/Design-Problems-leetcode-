package RifatSirCodes.TcpForward;

import RifatSirCodes.util.NetworkUtil;

import java.util.Scanner;

class Client {
    Client(String serverIP, int serverPort) {
        try {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter the name of the Client: ");
            String clientName = scanner.nextLine();

            NetworkUtil nc = new NetworkUtil(serverIP, serverPort);
            nc.write(clientName);   // important for server to map a client & not handled by WriteThreadClient
            System.out.println(clientName + " connected, RemotePort: " + nc.remotePort() + ", LocalPort: " + nc.localPort());

            new ReadThreadClient(nc);
            new WriteThreadClient(nc, clientName);  //name will be used
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void main(String[] args) {
        Client client = new Client("localhost", 6666);
    }
}
