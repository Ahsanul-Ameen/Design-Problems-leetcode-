package RifatSirCodes.TcpObject;

import RifatSirCodes.util.NetworkUtil;

public class ReadThread implements Runnable {
    private NetworkUtil nc;
    private Thread th;

    ReadThread(NetworkUtil nc) {
        this.nc = nc;
        th = new Thread(this);
        th.start();
    }

    @Override
    public void run() {
        try {
            while (true) {
                Object o = nc.read();
                if(o != null && o instanceof Data) {
                    Data data = (Data) o;
                    System.out.println(data.getElement());
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            nc.closeConnection();
        }
    }
}
