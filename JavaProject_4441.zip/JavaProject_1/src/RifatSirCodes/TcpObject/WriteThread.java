package RifatSirCodes.TcpObject;

import RifatSirCodes.util.NetworkUtil;

import java.util.Scanner;

class WriteThread implements Runnable {
    private NetworkUtil nc;
    private Thread th;
    private String name;

    WriteThread(NetworkUtil nc, String name) {
        this.nc = nc;
        this.name = name;
        th = new Thread(this);
        th.start();
    }


    @Override
    public void run() {
        try {
            Scanner input = new Scanner(System.in);
            while (true) {
                String s = input.nextLine();
                Data d = new Data(name + ": " + s);
                nc.write(d);
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            nc.closeConnection();
        }
    }
}
