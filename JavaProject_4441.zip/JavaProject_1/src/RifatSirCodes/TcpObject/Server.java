package RifatSirCodes.TcpObject;

import RifatSirCodes.util.NetworkUtil;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    private ServerSocket serverSocket;

    Server() {
        try {
            serverSocket = new ServerSocket(6666);
            while(true) {
                Socket socket = serverSocket.accept();
                serve(socket);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void serve(Socket clientSocket) {
        NetworkUtil nc = new NetworkUtil(clientSocket);
        new ReadThread(nc);
        new WriteThread(nc, "Server");
    }

    public static void main(String[] args) {
        Server server = new Server();
    }

}


