package RifatSirCodes.util;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class NetworkUtil {
    private Socket socket;
    private ObjectInputStream objectInputStream;
    private ObjectOutputStream objectOutputStream;

    public NetworkUtil(Socket socket) {
        try {
            this.socket = socket;
            objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
            objectInputStream = new ObjectInputStream(socket.getInputStream());
        } catch (IOException e) {
            System.out.println("In NetworkUtil : " + e.toString());
        }
    }

    public NetworkUtil(String serverIP, int serverPort) {
        try {
            this.socket = new Socket(serverIP, serverPort);
            objectInputStream = new ObjectInputStream(socket.getInputStream());
            objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
        } catch (IOException e) {
            System.out.println("In NetworkUtil : " + e.toString());
        }
    }

    public Object read() {
        Object o = null;
        try {
            o = objectInputStream.readUnshared(); // preferred over readObject()
        } catch (ClassNotFoundException | IOException e) {
            //System.out.println("Reading Error in Network : " + e.toString());
        }
        return o;
    }

    public void write(Object o) {
        try {
            objectOutputStream.writeUnshared(o);    // preferred over writeObject(...)
        } catch (IOException e) {
            System.out.println("Writing Error in Network : " + e.toString());
        }
    }

    public void closeConnection() {
        try {
            objectInputStream.close();
            objectOutputStream.close();
            socket.close();
        } catch (IOException e) {
            System.out.println("Closing(Buffer) error in Network : " + e.toString());
        }
    }

    public int localPort() {
        return this.socket.getLocalPort();
    }

    public int remotePort() {
        return this.socket.getPort();
    }
}
