package RifatSirCodes.Online;


import RifatSirCodes.util.NetworkUtil;

import java.util.Scanner;

public class Client {
    private int id;
    Client(String serverIP, int serverPort) {
        try {
            Scanner scanner = new Scanner(System.in);
            NetworkUtil nc = new NetworkUtil(serverIP, serverPort);

            //read id;
            id = (int) nc.read();
            System.out.println("Your ID: " + id);

            while(true) {
                System.out.println("Enter a choice: (GET id / SET status)");
                String s = scanner.nextLine();
                if(s.equalsIgnoreCase("GET")) {
                    s = scanner.nextLine();
                    Integer getID = Integer.parseInt(s);
                    nc.write("GET");
                    nc.write(getID);
                    System.out.println("Server: " + nc.read());

                } else if(s.equalsIgnoreCase("SET")) {
                    s = scanner.nextLine();
                    nc.write("SET");
                    nc.write(s);
                } else {
                    System.out.println("Invalid Choice, enter again...");
                }
            }


        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public static void main(String[] args) {
        Client client1 = new Client("localhost", 6666);
    }
}
