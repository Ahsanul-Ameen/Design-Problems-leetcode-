package RifatSirCodes.Online;

import RifatSirCodes.util.NetworkUtil;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

public class Server {
    private ServerSocket welcomeSocket;
    int clientCount = 0;
    public HashMap<Integer, NetworkUtil> clientMap;
    public HashMap<Integer, String> clientStatus;

    Server() {
        clientMap = new HashMap<>();
        clientStatus = new HashMap<>();
        try {
            welcomeSocket = new ServerSocket(6666);
            while(true) {
                Socket socket = welcomeSocket.accept();
                serve(socket);
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    private void serve(Socket socket) {
        ++clientCount;
        NetworkUtil nc = new NetworkUtil(socket);
        clientMap.put(clientCount, nc);
        clientStatus.put(clientCount, "No Status");

        new ReadThreadServer(clientCount, nc, clientMap, clientStatus);
    }

    public static void main(String[] args) {
        Server server = new Server();
    }

}
