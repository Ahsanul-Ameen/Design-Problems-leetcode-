package RifatSirCodes.Online;

import RifatSirCodes.util.NetworkUtil;

import java.util.HashMap;

public class ReadThreadServer implements Runnable {
    private int id;
    private NetworkUtil nc;
    public HashMap<Integer, NetworkUtil> clientMap;
    public HashMap<Integer, String> clientStatus;
    private Thread th;

    ReadThreadServer(int id, NetworkUtil nc, HashMap<Integer, NetworkUtil> clientMap, HashMap<Integer, String> clientStatus) {
        this.id = id;
        this.nc = nc; this.clientMap = clientMap; this.clientStatus = clientStatus;
        th = new Thread(this);
        th.start();
    }

    @Override
    public void run() {
        nc.write(id);   // write client's id to it

        while(true) {
            String s = (String) nc.read();
            if(s.equalsIgnoreCase("GET")) {
                Integer id = (Integer) nc.read();
                nc.write(clientStatus.get(id));
            } else if(s.equalsIgnoreCase("SET")) {
                s = (String) nc.read();
                clientStatus.replace(id, s);
            } else {
                //no need to handle
            }
        }

    }
}
