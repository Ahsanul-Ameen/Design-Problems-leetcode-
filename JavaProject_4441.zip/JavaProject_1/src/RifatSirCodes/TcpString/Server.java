package RifatSirCodes.TcpString;

import RifatSirCodes.util.NetworkUtil;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    private ServerSocket serverSocket;

    Server() {
        try {
            serverSocket = new ServerSocket(6666);
            while(true) {
                Socket clientSocket = serverSocket.accept();
                serve(clientSocket);
            }
        } catch (Exception e) {
            System.out.println("Server Starts: " + e);
        }
    }

    //generate new threads for read from client & write to client
    private void serve(Socket socket) {
        NetworkUtil nc = new NetworkUtil(socket);
        new ReadThread(nc);
        new WriteThread(nc, "Server");
    }

    public static void main(String[] args) {
        Server server = new Server();
    }
}
