package Week_1.WithThread;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

public class Server {
    public static void main(String[] args) throws IOException {
        ServerSocket welcomeSocket = new ServerSocket(6666);

        while(true) {
            System.out.println("Waiting for new Client Connection...");
            Socket socket = welcomeSocket.accept();
            System.out.println("Connection Established");

            //Worker worker = new Worker(socket);

            new Thread(()-> {
                //buffers
                try {
                    ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                    ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                    while(true) {
                        Thread.sleep(1000);
                        out.writeObject((new Date()).toString());
                    }
                } catch (IOException | InterruptedException e) { e.printStackTrace(); }
            }).start();
        }

    }
}
