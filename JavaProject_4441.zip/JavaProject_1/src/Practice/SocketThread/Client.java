package Practice.SocketThread;

import RifatSirCodes.util.NetworkUtil;

import java.util.Objects;
import java.util.Scanner;

class Client {
    NetworkUtil nc;
    Client(String serverIP, int serverPort) {
        try {
            Scanner input = new Scanner(System.in);
            nc = new NetworkUtil(serverIP, serverPort);
            while (true) {
                System.out.println(nc.read());
                int ch = input.nextInt();
                nc.write(ch);
                System.out.println(nc.read());
                Thread.sleep(1000);
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            Objects.requireNonNull(nc).closeConnection();
        }
    }

    public static void main(String[] args) {
        Client client = new Client("localhost", 6666);
    }
}
