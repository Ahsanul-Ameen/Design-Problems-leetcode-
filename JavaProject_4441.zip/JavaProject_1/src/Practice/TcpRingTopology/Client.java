package Practice.TcpRingTopology;

import RifatSirCodes.util.NetworkUtil;

import java.util.Objects;
import java.util.Scanner;

class Client {
    private int id;
    private NetworkUtil nc;
    Client(String serverIP, int serverPort) {
        try {
            Scanner scanner = new Scanner(System.in);
            nc = new NetworkUtil(serverIP, serverPort);
            int id = (int) nc.read();
            System.out.println("Your ID: " + id);
            new ReadThreadClient(nc);

            while(true) {
                System.out.println("Enter 1. next 2.prev and message");
                int ch = scanner.nextInt();
                assert (ch >= 1 && ch <= 2);
                nc.write(ch);
                String s = scanner.nextLine();
                nc.write(s);
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            Objects.requireNonNull(nc).closeConnection();
        }
    }

    public static void main(String[] args) {
       Client client = new Client("localhost", 6666);
    }
}