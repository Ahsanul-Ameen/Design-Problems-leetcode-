package Practice.TcpRingTopology;

import RifatSirCodes.util.NetworkUtil;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

class Server {
    private int clientCount = 0;
    private HashMap<Integer, NetworkUtil> clientMap;
    private ServerSocket serverSocket;

    Server() {
        clientMap = new HashMap<>();
        try {
            serverSocket = new ServerSocket(6666);
            while(true) {
                Socket clientSocket = serverSocket.accept();
                serve(clientSocket);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void serve(Socket socket) {
        ++clientCount;
        NetworkUtil nc = new NetworkUtil(socket);
        nc.write(clientCount);   // send ID number
        clientMap.put(clientCount, nc);
        new ClientHandler(clientMap, nc);
    }

    public static void main(String[] args) {
        Server server = new Server();
    }
}
