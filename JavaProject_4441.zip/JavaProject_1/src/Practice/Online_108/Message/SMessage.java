package Practice.Online_108.Message;

import java.io.Serializable;

public class SMessage implements Serializable {
    private String from, password, text;

    public SMessage(String from, String password, String text) {
        this.from = from;
        this.password = password;
        this.text = text;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getText() {
        return text;
    }

    public void setTo(String to) {
        this.text = to;
    }
}
