package Practice.Online_108.tcpdiff;


import Practice.Online_108.Message.BMessage;
import Practice.Online_108.Message.LMessage;
import Practice.Online_108.Message.SMessage;
import Practice.Online_108.util.NetworkUtil;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class ReadThreadServer implements Runnable {
    private Thread thr;
    private NetworkUtil nc;
    private HashMap<LMessage, NetworkUtil> clientMap;
    public HashMap<NetworkUtil, String> typeMap;

    public ReadThreadServer(HashMap<LMessage, NetworkUtil> clientMap,  HashMap<NetworkUtil, String> typeMap, NetworkUtil nc) {
        this.nc = nc;
        this.clientMap = clientMap;
        this.typeMap = typeMap;
        this.thr = new Thread(this);
        thr.start();
    }

    public void run() {
        try {
            while (true) {
                Object o = null;
                o = nc.read();

                if(o instanceof SMessage) {
                    SMessage sMessage = (SMessage) o;
                    NetworkUtil networkUtil = clientMap.get(new LMessage(sMessage.getFrom(), sMessage.getPassword(), ""));
                    if(nc == null) continue;
                    System.out.println("LMessage from " + sMessage.getFrom() + ": " + sMessage.getText());
                } else if(o instanceof BMessage) {
                    BMessage bMessage = (BMessage) o;
                    NetworkUtil networkUtil = clientMap.get(new LMessage(bMessage.getFrom(), bMessage.getPassword(), ""));
                    if(networkUtil == null) continue;
                    if(bMessage.isForserver()) {
                        System.out.println("BMessage from " + bMessage.getFrom() + ": " + bMessage.getText());
                    }
                    if(typeMap.get(networkUtil).equalsIgnoreCase("admin")) {
                        // show all balances in HashTable
                        Set set = clientMap.keySet(); // get set view of keys
                        // get iterator
                        Iterator<NetworkUtil> itr = set.iterator();
                        while (itr.hasNext()) {
                            NetworkUtil networkUtil1 = itr.next();
                            if(networkUtil1 != networkUtil) {
                                networkUtil1.write("Client " + bMessage.getFrom() + ": " + bMessage.getText());
                            }
                        }
                        System.out.println();
                    }

                } else if(o instanceof String) {
                    System.out.println(o);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            nc.closeConnection();
        }
    }
}



