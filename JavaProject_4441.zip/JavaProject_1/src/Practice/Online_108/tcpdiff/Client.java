package Practice.Online_108.tcpdiff;

import Practice.Online_108.Message.LMessage;
import Practice.Online_108.util.NetworkUtil;

import java.util.Scanner;



public class Client {

    public Client(String serverAddress, int serverPort) {
        try {
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter username of the client: ");
            String clientName = scanner.next();
            System.out.println("Enter password of the user: ");
            String password = scanner.next();
            System.out.println("Enter type (admin/normal)");
            String type = scanner.next();

            LMessage lMessage = new LMessage(clientName, password, type);

            NetworkUtil nc = new NetworkUtil(serverAddress, serverPort);
            nc.write(lMessage);   //write your  LMessage
            new ReadThreadClient(nc); // client read thread
            new WriteThreadClient(nc, clientName);  //client write thread
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void main(String args[]) {
        String serverAddress = "127.0.0.1";
        int serverPort = 33333;
        Client client = new Client(serverAddress, serverPort);
    }
}

