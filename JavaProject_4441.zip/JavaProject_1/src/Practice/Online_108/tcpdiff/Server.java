package Practice.Online_108.tcpdiff;

import Practice.Online_108.Message.LMessage;
import Practice.Online_108.util.NetworkUtil;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;



public class Server {

    private ServerSocket serverSocket;
    public int i = 1;
    public HashMap<LMessage, NetworkUtil> clientMap;
    public HashMap<NetworkUtil, String> typeMap;

    Server() {
        clientMap = new HashMap<>();
        typeMap = new HashMap<>();
        try {
            serverSocket = new ServerSocket(33333);
            new WriteThreadServer(clientMap, "Server"); // generate a writing thread for server with clientMap
            while (true) {
                Socket clientSocket = serverSocket.accept();
                serve(clientSocket);
            }
        } catch (Exception e) {
            System.out.println("Server starts:" + e);
        }
    }

    public void serve(Socket clientSocket) {
        NetworkUtil nc = new NetworkUtil(clientSocket);
        LMessage clientLMessage = (LMessage) nc.read(); // read new client's Login Message
        clientMap.put(clientLMessage, nc);  // username, password -> NetworkUtil mapping
        typeMap.put(nc, clientLMessage.getType());  // store type
        new ReadThreadServer(clientMap, typeMap, nc); // read from client
    }

    public static void main(String args[]) {
        Server server = new Server();
    }
}



